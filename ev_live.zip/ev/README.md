# EV

A live voice assistant for your laptop, built on the Gemini Live API. You talk, EV answers out loud, you can interrupt it mid-sentence, and it can act on your computer through 67 tools (see TOOLS.md).

Created by EV Studio. Operator: Arush.

## Set up (Windows)

1. Install Python 3.10 or newer from python.org. Tick "Add Python to PATH".
2. Make a Gemini key in Google AI Studio. Never paste it into a chat or commit it.
3. Double-click `start_ev.bat`. On the first run it creates `.env` and opens it. Paste your key after `GEMINI_API_KEY=`, save, and run the file again.
4. EV opens in its own app window. Click Wake EV, allow the microphone, and talk.

macOS and Linux: run `./start_ev.sh`. Install and uninstall work through winget on Windows and Homebrew on macOS. Volume, brightness, media keys, window focus and Settings pages are Windows only.

## How it works

Browser window <-> EV server on your computer <-> Gemini Live. The key stays on the server and never reaches the page. The server only answers on localhost, and it refuses any web page that is not EV's own, because EV can control your laptop.

Live voice only. There is no typing box. Use headphones so EV does not hear itself.

## Approvals

These tools wait for you to click Approve in the window (or press Esc to deny): install, uninstall, upgrade, delete, move, close program, type, press keys, click, power actions, temp cleanup, look at screen, run command, run Python, write file. Saying "yes" out loud does not approve anything.

To skip the dialog for specific tools, list them in `.env`: `EV_AUTO_APPROVE=press_keys,type_text`. Leave it empty if unsure.

## Installing and uninstalling apps

Say "install VLC". EV searches the package manager, picks the exact id, asks you to approve, then installs in the background and tells you when it finishes. "Uninstall VLC" and "update all my apps" work the same way.

## Files EV creates

`memory.json`, `reminders.json`, `todo.json` and the `workspace` folder, next to `server.py`. Delete any of them to erase that data. See `/privacy` in the app for exactly what goes to Google.

## Settings (.env)

| Setting | Meaning |
|---|---|
| `GEMINI_API_KEY` | Your key. Required. |
| `GEMINI_LIVE_MODEL` | Live voice model. Default `gemini-3.1-flash-live-preview`. |
| `GEMINI_AGENT_MODEL` | Model for the Researcher, Coder, Planner and Analyst agents. |
| `EV_USER_NAME` | What EV calls you. |
| `EV_OPERATOR` | Operator name EV gives when asked who made it. |
| `EV_VOICE` | Gemini voice name, for example Kore. |
| `NTFY_TOPIC` | Private topic for phone notifications through the ntfy app. |
| `EV_AUTO_APPROVE` | Tools allowed to skip the Approve dialog. |
| `EV_PORT` | Local port. Default 8000. |

## If something goes wrong

| What you see | Fix |
|---|---|
| Gemini rejected the API key | Make a new key in AI Studio and update `.env`. |
| The free Gemini limit has been reached | Wait a few minutes and wake EV again. |
| Gemini does not know the model | Change `GEMINI_LIVE_MODEL` in `.env`. |
| Microphone was blocked | Allow the microphone in the address bar, then try again. |
| Install says winget is not available | Install "App Installer" from the Microsoft Store. |

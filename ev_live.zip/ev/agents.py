"""Specialist agents. EV delegates to these when a job is bigger than a quick answer.

Each agent is a separate Gemini text call with its own instructions. They run only when
EV delegates a task to them, then return the finished answer.
"""

import os

from google import genai
from google.genai import types

AGENTS = {
    "researcher": {
        "label": "Researcher",
        "prompt": (
            "You are the research agent inside EV, a personal AI assistant. Use Google Search to find current, "
            "accurate information. Answer in under 200 words, lead with the answer, and name your sources."
        ),
        "search": True,
    },
    "coder": {
        "label": "Coder",
        "prompt": (
            "You are the coding agent inside EV. Write clean, working, well-structured code with short comments "
            "only where the logic is not obvious. Return the code first, then two lines on how to run it."
        ),
        "search": False,
    },
    "planner": {
        "label": "Planner",
        "prompt": (
            "You are the planning agent inside EV. Break the request into a short ordered plan with realistic "
            "timings. Flag the one step most likely to go wrong. Keep it under 150 words."
        ),
        "search": False,
    },
    "analyst": {
        "label": "Analyst",
        "prompt": (
            "You are the analysis agent inside EV. Compare options with real numbers, state your assumptions, "
            "show any arithmetic, and finish with a clear recommendation in one sentence."
        ),
        "search": False,
    },
}

_client = None


def _get_client():
    global _client
    if _client is None:
        _client = genai.Client(api_key=os.environ["GEMINI_API_KEY"])
    return _client


async def delegate(agent: str, task: str) -> dict:
    spec = AGENTS.get(agent)
    if spec is None:
        return {"error": f"No agent called {agent}."}
    config = types.GenerateContentConfig(
        system_instruction=spec["prompt"],
        tools=[types.Tool(google_search=types.GoogleSearch())] if spec["search"] else None,
    )
    try:
        reply = await _get_client().aio.models.generate_content(
            model=os.environ.get("GEMINI_AGENT_MODEL", "gemini-2.5-flash"),
            contents=task,
            config=config,
        )
    except Exception as exc:
        return {"error": f"The {spec['label']} agent failed: {exc}"}
    return {"agent": spec["label"], "answer": (reply.text or "").strip()}

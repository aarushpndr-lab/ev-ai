#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1

[ -f .env ] || { cp .env.example .env; echo "Created .env. Add your Gemini key to it, then run this again."; exit 0; }

if [ ! -x .venv/bin/python ]; then
  echo "First run. Setting up EV."
  python3 -m venv .venv && . .venv/bin/activate && pip install --quiet -r requirements.txt || exit 1
else
  . .venv/bin/activate
fi

( sleep 3; (xdg-open http://localhost:8000 || open http://localhost:8000) >/dev/null 2>&1 ) &
python server.py

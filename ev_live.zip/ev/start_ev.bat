@echo off
setlocal
cd /d "%~dp0"
title EV

if not exist .env (
  copy .env.example .env >nul
  echo A .env file was created. Paste your Gemini key after GEMINI_API_KEY= and save it.
  notepad .env
  pause
)

if not exist .venv\Scripts\python.exe (
  echo First run. Setting up EV, this takes a minute or two.
  python -m venv .venv
  if errorlevel 1 (
    echo Python 3.10 or newer is needed. Install it from python.org and tick "Add Python to PATH".
    pause
    exit /b 1
  )
  call .venv\Scripts\activate.bat
  python -m pip install --quiet --upgrade pip
  pip install --quiet -r requirements.txt
  if errorlevel 1 (
    echo Installing the packages failed. Check your internet connection and run this file again.
    pause
    exit /b 1
  )
) else (
  call .venv\Scripts\activate.bat
)

start "" powershell -WindowStyle Hidden -Command "Start-Sleep 4; try { Start-Process msedge '--app=http://localhost:8000' } catch { Start-Process 'http://localhost:8000' }"

echo EV is running. Close this window to shut EV down.
python server.py
pause

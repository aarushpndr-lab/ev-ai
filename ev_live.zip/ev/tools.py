"""Local tools EV can call. Each tool returns a JSON-serializable dict."""

import asyncio
import json
import platform
import re
import subprocess
import sys
import time
import webbrowser
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import quote_plus

import httpx
import psutil

BASE = Path(__file__).parent
WORKSPACE = BASE / "workspace"
WORKSPACE.mkdir(exist_ok=True)
MEMORY_FILE = BASE / "memory.json"
REMINDER_FILE = BASE / "reminders.json"

IS_WINDOWS = platform.system() == "Windows"

# Tools that change things on the machine. The server asks the user to approve these first.
CONFIRM_REQUIRED = {"run_command", "run_python", "write_file"}


def _load(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def _save(path: Path, data) -> None:
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def _safe_path(name: str) -> Path:
    """Resolve a filename inside the workspace folder and refuse anything outside it."""
    target = (WORKSPACE / name).resolve()
    if WORKSPACE.resolve() not in target.parents and target != WORKSPACE.resolve():
        raise ValueError("Path is outside the workspace folder.")
    return target


# ---------------------------------------------------------------- information

def get_time() -> dict:
    now = datetime.now()
    return {"time": now.strftime("%I:%M %p"), "date": now.strftime("%A, %d %B %Y")}


def system_status() -> dict:
    battery = psutil.sensors_battery()
    disk_root = Path.home().anchor or "/"
    return {
        "cpu_percent": psutil.cpu_percent(interval=0.2),
        "cpu_cores": psutil.cpu_count(logical=True),
        "ram_percent": psutil.virtual_memory().percent,
        "ram_used_gb": round(psutil.virtual_memory().used / 1e9, 1),
        "ram_total_gb": round(psutil.virtual_memory().total / 1e9, 1),
        "disk_percent": psutil.disk_usage(disk_root).percent,
        "battery_percent": round(battery.percent) if battery else None,
        "charging": battery.power_plugged if battery else None,
        "uptime_hours": round((time.time() - psutil.boot_time()) / 3600, 1),
        "os": f"{platform.system()} {platform.release()}",
    }


async def get_weather(city: str = "") -> dict:
    """Current weather from open-meteo. With no city, uses the approximate location of the IP."""
    async with httpx.AsyncClient(timeout=10) as client:
        if city:
            geo = (await client.get(
                "https://geocoding-api.open-meteo.com/v1/search",
                params={"name": city, "count": 1},
            )).json()
            if not geo.get("results"):
                return {"error": f"Could not find a place called {city}."}
            place = geo["results"][0]
            lat, lon, label = place["latitude"], place["longitude"], place["name"]
        else:
            loc = (await client.get("https://ipwho.is/")).json()
            if not loc.get("success", True):
                return {"error": "Could not work out your location."}
            lat, lon, label = loc["latitude"], loc["longitude"], loc.get("city", "your location")
        data = (await client.get(
            "https://api.open-meteo.com/v1/forecast",
            params={
                "latitude": lat,
                "longitude": lon,
                "current": "temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,weather_code",
                "timezone": "auto",
            },
        )).json()
    cur = data["current"]
    return {
        "place": label,
        "temperature_c": cur["temperature_2m"],
        "feels_like_c": cur["apparent_temperature"],
        "humidity_percent": cur["relative_humidity_2m"],
        "wind_kmh": cur["wind_speed_10m"],
        "condition": WEATHER_CODES.get(cur["weather_code"], "unknown"),
    }


WEATHER_CODES = {
    0: "clear sky", 1: "mostly clear", 2: "partly cloudy", 3: "overcast",
    45: "fog", 48: "freezing fog", 51: "light drizzle", 53: "drizzle", 55: "heavy drizzle",
    61: "light rain", 63: "rain", 65: "heavy rain", 71: "light snow", 73: "snow", 75: "heavy snow",
    80: "rain showers", 81: "heavy rain showers", 82: "violent rain showers",
    95: "thunderstorm", 96: "thunderstorm with hail", 99: "severe thunderstorm with hail",
}


async def web_search(query: str) -> dict:
    """Plain DuckDuckGo HTML search. Returns the top results with titles, links and snippets."""
    async with httpx.AsyncClient(timeout=12, follow_redirects=True, headers={"User-Agent": "Mozilla/5.0"}) as client:
        page = await client.post("https://html.duckduckgo.com/html/", data={"q": query})
    results = []
    blocks = re.findall(r'<a rel="nofollow" class="result__a" href="(.*?)">(.*?)</a>.*?<a class="result__snippet".*?>(.*?)</a>', page.text, re.S)
    for href, title, snippet in blocks[:6]:
        clean = lambda s: re.sub(r"<.*?>", "", s).replace("&amp;", "&").replace("&#x27;", "'").strip()
        match = re.search(r"uddg=([^&]+)", href)
        link = httpx.URL(href).params.get("uddg", href) if match else href
        results.append({"title": clean(title), "url": link, "snippet": clean(snippet)})
    return {"query": query, "results": results} if results else {"error": "No results came back."}


# ---------------------------------------------------------------- memory

def remember(fact: str) -> dict:
    facts = _load(MEMORY_FILE, [])
    facts.append({"fact": fact, "saved": datetime.now().isoformat(timespec="minutes")})
    _save(MEMORY_FILE, facts)
    return {"saved": fact, "total_facts": len(facts)}


def recall(query: str = "") -> dict:
    facts = _load(MEMORY_FILE, [])
    if query:
        words = query.lower().split()
        facts = [f for f in facts if any(w in f["fact"].lower() for w in words)]
    return {"facts": [f["fact"] for f in facts[-25:]]}


def forget(fact_contains: str) -> dict:
    facts = _load(MEMORY_FILE, [])
    kept = [f for f in facts if fact_contains.lower() not in f["fact"].lower()]
    _save(MEMORY_FILE, kept)
    return {"removed": len(facts) - len(kept)}


def memory_context() -> str:
    facts = [f["fact"] for f in _load(MEMORY_FILE, [])][-40:]
    return "\n".join(f"- {f}" for f in facts)


# ---------------------------------------------------------------- reminders

def set_reminder(message: str, minutes_from_now: float = 0, at_time: str = "") -> dict:
    """Either minutes_from_now, or at_time as HH:MM in 24-hour local time."""
    now = datetime.now()
    if at_time:
        try:
            hour, minute = [int(x) for x in at_time.split(":")[:2]]
        except ValueError:
            return {"error": "at_time must look like 17:30."}
        due = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
        if due <= now:
            due += timedelta(days=1)
    elif minutes_from_now > 0:
        due = now + timedelta(minutes=minutes_from_now)
    else:
        return {"error": "Give me minutes_from_now or at_time."}
    items = _load(REMINDER_FILE, [])
    item = {"id": int(time.time() * 1000), "message": message, "due": due.isoformat(timespec="seconds"), "fired": False}
    items.append(item)
    _save(REMINDER_FILE, items)
    return {"set": message, "due": due.strftime("%A %I:%M %p")}


def list_reminders() -> dict:
    items = [i for i in _load(REMINDER_FILE, []) if not i["fired"]]
    return {"reminders": [{"message": i["message"], "due": i["due"]} for i in sorted(items, key=lambda i: i["due"])]}


def cancel_reminder(message_contains: str) -> dict:
    items = _load(REMINDER_FILE, [])
    kept = [i for i in items if i["fired"] or message_contains.lower() not in i["message"].lower()]
    _save(REMINDER_FILE, kept)
    return {"cancelled": len(items) - len(kept)}


def pop_due_reminders() -> list:
    """Called by the server's watcher loop. Returns reminders that just came due."""
    items = _load(REMINDER_FILE, [])
    due, now = [], datetime.now()
    for item in items:
        if not item["fired"] and datetime.fromisoformat(item["due"]) <= now:
            item["fired"] = True
            due.append(item)
    if due:
        _save(REMINDER_FILE, items)
    return due


# ---------------------------------------------------------------- notes / files

def list_files() -> dict:
    return {"files": sorted(p.name for p in WORKSPACE.iterdir() if p.is_file())}


def read_file(name: str) -> dict:
    path = _safe_path(name)
    if not path.is_file():
        return {"error": f"{name} does not exist in the workspace."}
    return {"name": name, "content": path.read_text(encoding="utf-8", errors="replace")[:20000]}


def write_file(name: str, content: str) -> dict:
    path = _safe_path(name)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return {"written": name, "bytes": len(content.encode("utf-8"))}


# ---------------------------------------------------------------- laptop control

SITES = {
    "youtube": "https://www.youtube.com", "google": "https://www.google.com",
    "gmail": "https://mail.google.com", "maps": "https://maps.google.com",
    "github": "https://github.com", "chatgpt": "https://chatgpt.com",
    "whatsapp": "https://web.whatsapp.com", "instagram": "https://www.instagram.com",
    "spotify": "https://open.spotify.com", "netflix": "https://www.netflix.com",
}

WINDOWS_APPS = {
    "notepad": "notepad", "calculator": "calc", "paint": "mspaint", "explorer": "explorer",
    "settings": "ms-settings:", "task manager": "taskmgr", "cmd": "cmd", "vscode": "code",
    "chrome": "chrome", "edge": "msedge", "word": "winword", "excel": "excel",
}
MAC_APPS = {"calculator": "Calculator", "notes": "Notes", "chrome": "Google Chrome", "safari": "Safari", "terminal": "Terminal"}
LINUX_APPS = {"calculator": "gnome-calculator", "terminal": "x-terminal-emulator", "files": "xdg-open ."}


def open_website(site_or_url: str) -> dict:
    target = SITES.get(site_or_url.lower().strip(), site_or_url)
    if not re.match(r"^https?://", target):
        target = "https://" + target
    webbrowser.open(target)
    return {"opened": target}


def search_in_browser(query: str) -> dict:
    url = "https://www.google.com/search?q=" + quote_plus(query)
    webbrowser.open(url)
    return {"opened": url}


def play_on_youtube(query: str) -> dict:
    url = "https://www.youtube.com/results?search_query=" + quote_plus(query)
    webbrowser.open(url)
    return {"opened": url}


def open_app(name: str) -> dict:
    key = name.lower().strip()
    try:
        if IS_WINDOWS:
            command = WINDOWS_APPS.get(key, key)
            subprocess.Popen(f'start "" "{command}"' if command.endswith(":") else f"start {command}", shell=True)
        elif platform.system() == "Darwin":
            subprocess.Popen(["open", "-a", MAC_APPS.get(key, name)])
        else:
            subprocess.Popen(LINUX_APPS.get(key, key).split())
    except Exception as exc:
        return {"error": f"Could not open {name}: {exc}"}
    return {"opened": name}


def run_command(command: str) -> dict:
    """Runs a shell command in the workspace folder. The user approves every call first."""
    try:
        done = subprocess.run(command, shell=True, cwd=WORKSPACE, capture_output=True, text=True, timeout=30)
    except subprocess.TimeoutExpired:
        return {"error": "Command took longer than 30 seconds and was stopped."}
    return {"exit_code": done.returncode, "stdout": done.stdout[-4000:], "stderr": done.stderr[-2000:]}


def run_python(code: str) -> dict:
    """Runs Python code in the workspace folder. The user approves every call first."""
    script = WORKSPACE / "_ev_run.py"
    script.write_text(code, encoding="utf-8")
    try:
        done = subprocess.run([sys.executable, str(script)], cwd=WORKSPACE, capture_output=True, text=True, timeout=30)
    except subprocess.TimeoutExpired:
        return {"error": "Code took longer than 30 seconds and was stopped."}
    return {"exit_code": done.returncode, "stdout": done.stdout[-4000:], "stderr": done.stderr[-2000:]}


# ---------------------------------------------------------------- registry

def _decl(name, description, properties=None, required=None):
    schema = {"type": "OBJECT", "properties": properties or {}}
    if required:
        schema["required"] = required
    return {"name": name, "description": description, "parameters": schema}


S = {"type": "STRING"}
N = {"type": "NUMBER"}

DECLARATIONS = [
    _decl("get_time", "Current local time and date."),
    _decl("system_status", "Live CPU, memory, disk, battery and uptime of this computer."),
    _decl("get_weather", "Current weather. Leave city empty for the user's own location.", {"city": S}),
    _decl("web_search", "Search the web for fresh information and return the top results.", {"query": S}, ["query"]),
    _decl("remember", "Save a lasting fact about the user or their preferences.", {"fact": S}, ["fact"]),
    _decl("recall", "Look up saved facts. Leave query empty to list recent ones.", {"query": S}),
    _decl("forget", "Delete saved facts containing this text.", {"fact_contains": S}, ["fact_contains"]),
    _decl("set_reminder", "Set a spoken reminder, either minutes from now or at a 24-hour HH:MM time.",
          {"message": S, "minutes_from_now": N, "at_time": S}, ["message"]),
    _decl("list_reminders", "List upcoming reminders."),
    _decl("cancel_reminder", "Cancel reminders whose text contains this phrase.", {"message_contains": S}, ["message_contains"]),
    _decl("list_files", "List files in EV's workspace folder."),
    _decl("read_file", "Read a text file from the workspace folder.", {"name": S}, ["name"]),
    _decl("write_file", "Write a text file into the workspace folder. The user must approve.", {"name": S, "content": S}, ["name", "content"]),
    _decl("open_website", "Open a website or well-known site name (youtube, gmail, maps) in the browser.", {"site_or_url": S}, ["site_or_url"]),
    _decl("search_in_browser", "Open a Google search for a query in the browser.", {"query": S}, ["query"]),
    _decl("play_on_youtube", "Open YouTube search results for a song or video.", {"query": S}, ["query"]),
    _decl("open_app", "Open an application on this computer by name.", {"name": S}, ["name"]),
    _decl("run_command", "Run a shell command in the workspace folder. The user must approve.", {"command": S}, ["command"]),
    _decl("run_python", "Run Python code in the workspace folder and return the output. The user must approve.", {"code": S}, ["code"]),
    _decl("delegate_to_agent",
          "Hand a bigger job to a specialist agent and get its finished answer. "
          "Agents: researcher (deep web-grounded research), coder (writes and reviews code), "
          "planner (plans, schedules, step-by-step breakdowns), analyst (numbers, comparisons, decisions).",
          {"agent": {"type": "STRING", "enum": ["researcher", "coder", "planner", "analyst"]}, "task": S}, ["agent", "task"]),
]

REGISTRY = {
    "get_time": get_time, "system_status": system_status, "get_weather": get_weather,
    "web_search": web_search, "remember": remember, "recall": recall, "forget": forget,
    "set_reminder": set_reminder, "list_reminders": list_reminders, "cancel_reminder": cancel_reminder,
    "list_files": list_files, "read_file": read_file, "write_file": write_file,
    "open_website": open_website, "search_in_browser": search_in_browser, "play_on_youtube": play_on_youtube,
    "open_app": open_app, "run_command": run_command, "run_python": run_python,
}


async def call(name: str, args: dict) -> dict:
    func = REGISTRY.get(name)
    if func is None:
        return {"error": f"No tool called {name}."}
    try:
        if asyncio.iscoroutinefunction(func):
            return await func(**args)
        return await asyncio.to_thread(func, **args)
    except TypeError as exc:
        return {"error": f"Bad arguments for {name}: {exc}"}
    except Exception as exc:
        return {"error": f"{name} failed: {exc}"}

(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const el = {
    wake: $("wake"), wakeBtn: $("wakeBtn"), wakeNote: $("wakeNote"), wakeRing: $("wakeRing"),
    hud: $("hud"), dot: $("statusDot"), statusText: $("statusText"), spec: $("spec"), clock: $("clock"),
    agents: $("agentList"), meters: $("sysMeters"), sysMeta: $("sysMeta"), weather: $("weather"), reminders: $("reminderList"),
    orb: $("orb"), preview: $("preview"), caption: $("caption"),
    micBtn: $("micBtn"), camBtn: $("camBtn"), screenBtn: $("screenBtn"), sleepBtn: $("sleepBtn"),
    log: $("log"), activity: $("activity"),
    confirm: $("confirm"), confirmWhat: $("confirmWhat"), confirmBody: $("confirmBody"),
    allow: $("allowBtn"), deny: $("denyBtn"),
  };

  const state = {
    phase: "offline", ws: null, micOn: true, sleeping: false, fatal: false, retries: 0,
    micLevel: 0, outLevel: 0, running: 0, video: null, videoTimer: null,
  };

  const COLORS = {
    offline: [70, 110, 128], listening: [63, 216, 255], speaking: [120, 235, 255],
    thinking: [255, 179, 71], error: [255, 91, 91],
  };

  // ------------------------------------------------------------ audio

  let playCtx = null, analyser = null, micCtx = null, micStream = null, micNode = null;
  let nextTime = 0;
  const sources = new Set();
  const freq = new Uint8Array(128);

  function createContexts() {
    playCtx = new AudioContext({ sampleRate: 24000 });
    analyser = playCtx.createAnalyser();
    analyser.fftSize = 256;
    analyser.smoothingTimeConstant = 0.6;
    analyser.connect(playCtx.destination);
    micCtx = new AudioContext();
  }

  async function startMic() {
    await micCtx.audioWorklet.addModule("/static/mic-worklet.js");
    micStream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 },
    });
    const source = micCtx.createMediaStreamSource(micStream);
    micNode = new AudioWorkletNode(micCtx, "mic-processor");
    const silent = micCtx.createGain();
    silent.gain.value = 0;
    source.connect(micNode);
    micNode.connect(silent);
    silent.connect(micCtx.destination);

    micNode.port.onmessage = (event) => {
      const pcm = new Int16Array(event.data);
      let sum = 0;
      for (let i = 0; i < pcm.length; i++) sum += (pcm[i] / 32768) ** 2;
      const rms = Math.sqrt(sum / pcm.length);
      state.micLevel += (Math.min(1, rms * 6) - state.micLevel) * 0.4;
      if (state.micOn && state.ws && state.ws.readyState === WebSocket.OPEN) state.ws.send(event.data);
    };
  }

  function stopMic() {
    if (micStream) micStream.getTracks().forEach((t) => t.stop());
    micStream = null;
    if (micNode) micNode.disconnect();
    micNode = null;
  }

  function playChunk(buffer) {
    if (!playCtx) return;
    if (playCtx.state === "suspended") playCtx.resume();
    const pcm = new Int16Array(buffer);
    const samples = new Float32Array(pcm.length);
    for (let i = 0; i < pcm.length; i++) samples[i] = pcm[i] / 32768;
    const audio = playCtx.createBuffer(1, samples.length, 24000);
    audio.copyToChannel(samples, 0);
    const node = playCtx.createBufferSource();
    node.buffer = audio;
    node.connect(analyser);
    const start = Math.max(playCtx.currentTime + 0.02, nextTime);
    node.start(start);
    nextTime = start + audio.duration;
    sources.add(node);
    node.onended = () => {
      sources.delete(node);
      if (!sources.size && state.phase === "speaking") setPhase(state.running ? "thinking" : "listening");
    };
    setPhase("speaking");
  }

  function stopPlayback() {
    sources.forEach((node) => { try { node.stop(); } catch (_) { /* already stopped */ } });
    sources.clear();
    nextTime = 0;
  }

  // ------------------------------------------------------------ camera and screen

  async function toggleVideo(kind) {
    const wasKind = state.video && state.video.kind;
    stopVideo();
    if (wasKind === kind) return;
    try {
      const stream = kind === "camera"
        ? await navigator.mediaDevices.getUserMedia({ video: { width: 960, height: 600 } })
        : await navigator.mediaDevices.getDisplayMedia({ video: true });
      state.video = { kind, stream };
      el.preview.srcObject = stream;
      el.preview.hidden = false;
      await el.preview.play();
      stream.getVideoTracks()[0].addEventListener("ended", stopVideo);
      state.videoTimer = setInterval(sendFrame, 1000);
      markVideoButtons();
    } catch (err) {
      stopVideo();
      addActivity("notice", `Could not start ${kind}: ${err.name}`);
    }
  }

  function stopVideo() {
    if (state.videoTimer) clearInterval(state.videoTimer);
    state.videoTimer = null;
    if (state.video) state.video.stream.getTracks().forEach((t) => t.stop());
    state.video = null;
    el.preview.srcObject = null;
    el.preview.hidden = true;
    markVideoButtons();
  }

  function markVideoButtons() {
    const kind = state.video && state.video.kind;
    el.camBtn.classList.toggle("live", kind === "camera");
    el.camBtn.setAttribute("aria-pressed", String(kind === "camera"));
    el.screenBtn.classList.toggle("live", kind === "screen");
    el.screenBtn.setAttribute("aria-pressed", String(kind === "screen"));
  }

  const frameCanvas = document.createElement("canvas");
  function sendFrame() {
    const v = el.preview;
    if (!v.videoWidth || !state.ws || state.ws.readyState !== WebSocket.OPEN) return;
    const scale = Math.min(1, 960 / v.videoWidth);
    frameCanvas.width = Math.round(v.videoWidth * scale);
    frameCanvas.height = Math.round(v.videoHeight * scale);
    frameCanvas.getContext("2d").drawImage(v, 0, 0, frameCanvas.width, frameCanvas.height);
    const data = frameCanvas.toDataURL("image/jpeg", 0.6).split(",")[1];
    state.ws.send(JSON.stringify({ type: "video", data }));
  }

  // ------------------------------------------------------------ socket

  function connect(fresh) {
    const scheme = location.protocol === "https:" ? "wss" : "ws";
    const ws = new WebSocket(`${scheme}://${location.host}/ws${fresh ? "?fresh=1" : ""}`);
    ws.binaryType = "arraybuffer";
    state.ws = ws;
    setPhase("offline", "Connecting");

    ws.onmessage = (event) => {
      if (event.data instanceof ArrayBuffer) return playChunk(event.data);
      handle(JSON.parse(event.data));
    };

    ws.onclose = () => {
      if (state.ws !== ws) return;
      stopPlayback();
      if (state.sleeping || state.fatal) return;
      if (state.retries >= 5) return giveUp("EV lost the connection. Check that the EV window is still running.");
      state.retries += 1;
      setPhase("offline", "Reconnecting");
      setTimeout(() => { if (!state.sleeping && !state.fatal) connect(false); }, 1500);
    };
  }

  function handle(msg) {
    switch (msg.type) {
      case "ready":
        state.retries = 0;
        setPhase("listening");
        setCaption(msg.resumed ? "Back online." : "Say something. EV is listening.", true);
        break;
      case "transcript":
        addTranscript(msg.role, msg.text);
        break;
      case "turn_complete":
        current = null;
        evCaption = "";
        break;
      case "interrupted":
        stopPlayback();
        setPhase(state.running ? "thinking" : "listening");
        break;
      case "tool":
        toolEvent(msg);
        break;
      case "agent":
        setAgent(msg.agent, msg.status);
        break;
      case "confirm":
        approvals.push(msg);
        showApproval();
        break;
      case "reminder":
        addActivity("notice", `Reminder: ${msg.message}`);
        loadReminders();
        break;
      case "notice":
        addActivity("notice", msg.message);
        break;
      case "error":
        addActivity("failed", msg.message);
        if (msg.fatal) { state.fatal = true; giveUp(msg.message); }
        break;
    }
  }

  // ------------------------------------------------------------ state, transcript, activity

  function setPhase(phase, label) {
    state.phase = phase;
    const names = { offline: "Offline", listening: "Listening", speaking: "Speaking", thinking: "Working", error: "Error" };
    el.statusText.textContent = label || names[phase];
    el.dot.className = "dot " + ({ listening: "ok", speaking: "ok", thinking: "busy", error: "bad" }[phase] || "");
  }

  let evCaption = "";
  function setCaption(text, dim) {
    el.caption.textContent = text;
    el.caption.classList.toggle("dim", !!dim);
  }

  let current = null;
  function addTranscript(role, text) {
    if (!current || current.role !== role) {
      const wrap = document.createElement("div");
      wrap.className = "msg " + role;
      const who = document.createElement("span");
      who.className = "who";
      who.textContent = role === "ev" ? "EV" : "You";
      const body = document.createElement("span");
      wrap.append(who, body);
      el.log.append(wrap);
      while (el.log.children.length > 60) el.log.firstChild.remove();
      current = { role, body, text: "" };
    }
    current.text += text;
    current.body.textContent = current.text.trim();
    el.log.scrollTop = el.log.scrollHeight;
    if (role === "ev") {
      evCaption += text;
      setCaption(evCaption.trim().slice(-190));
    } else {
      setCaption(current.text.trim().slice(-190), true);
    }
  }

  const label = (name) => name.replace(/_/g, " ");

  function addActivity(status, text, key) {
    const li = document.createElement("li");
    li.className = status;
    if (key) li.dataset.key = key;
    const name = document.createElement("span");
    name.textContent = text;
    const st = document.createElement("span");
    st.className = "st";
    if (status !== "notice") st.textContent = status;
    li.append(name, st);
    el.activity.prepend(li);
    while (el.activity.children.length > 14) el.activity.lastChild.remove();
    return li;
  }

  const live = {};
  function toolEvent(msg) {
    if (msg.status === "running") {
      state.running += 1;
      setPhase("thinking");
      live[msg.name] = addActivity("running", label(msg.name), msg.name);
      return;
    }
    state.running = Math.max(0, state.running - 1);
    const li = live[msg.name];
    if (li) {
      li.className = msg.status;
      li.querySelector(".st").textContent = msg.status;
    }
    if (!state.running && state.phase === "thinking") setPhase(sources.size ? "speaking" : "listening");
  }

  function setAgent(key, status) {
    const li = el.agents.querySelector(`[data-key="${key}"]`);
    if (!li) return;
    li.classList.toggle("working", status === "working");
    li.querySelector(".state").textContent = status === "working" ? "working" : "idle";
  }

  // ------------------------------------------------------------ approvals

  const WHAT = {
    install_app: (a) => `Install the app ${a.package_id}`,
    uninstall_app: (a) => `Uninstall the app ${a.package_id}`,
    upgrade_app: (a) => (String(a.package_id).toLowerCase() === "all" ? "Update every installed app" : `Update ${a.package_id}`),
    delete_file: (a) => `Move to the Recycle Bin: ${a.path}`,
    move_file: (a) => `${a.copy ? "Copy" : "Move"} ${a.source} to ${a.destination}`,
    kill_process: (a) => `Force close every program named ${a.name}`,
    type_text: () => "Type this text into the focused window",
    press_keys: (a) => `Press ${a.keys}`,
    mouse_click: (a) => `Click the screen at ${a.x}, ${a.y}`,
    power_action: (a) => `Power action: ${a.action}`,
    clean_temp_files: () => "Delete temporary files older than two days",
    look_at_screen: () => "Take one picture of your screen and show it to EV. It is sent to Google.",
    run_command: () => "Run this command on your computer",
    run_python: () => "Run this Python code on your computer",
    write_file: (a) => `Write the file ${a.name}`,
  };

  const approvals = [];
  let activeApproval = null;

  function showApproval() {
    if (activeApproval || !approvals.length) return;
    activeApproval = approvals.shift();
    const a = activeApproval.args || {};
    el.confirmWhat.textContent = (WHAT[activeApproval.tool] || (() => `Run ${label(activeApproval.tool)}`))(a);
    const body = a.command || a.code || a.content || a.text || JSON.stringify(a, null, 2);
    el.confirmBody.textContent = body === "{}" ? "No extra details." : body;
    el.confirm.hidden = false;
    el.deny.focus();
  }

  function answerApproval(ok) {
    if (!activeApproval) return;
    if (state.ws && state.ws.readyState === WebSocket.OPEN) {
      state.ws.send(JSON.stringify({ type: "confirm_result", id: activeApproval.id, ok }));
    }
    activeApproval = null;
    el.confirm.hidden = true;
    showApproval();
  }

  el.allow.addEventListener("click", () => answerApproval(true));
  el.deny.addEventListener("click", () => answerApproval(false));
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && activeApproval) answerApproval(false); });

  // ------------------------------------------------------------ wake, sleep, controls

  function showWake(note, isError) {
    el.hud.hidden = true;
    el.wake.hidden = false;
    el.wake.classList.toggle("error", !!isError);
    el.wakeNote.textContent = note;
    el.wakeBtn.disabled = false;
    el.wakeBtn.textContent = isError ? "Try again" : "Wake EV";
  }

  function giveUp(message) {
    stopMic();
    stopVideo();
    stopPlayback();
    if (state.ws) { const ws = state.ws; state.ws = null; ws.close(); }
    setPhase("error");
    showWake(message, true);
  }

  async function wake() {
    el.wakeBtn.disabled = true;
    el.wakeNote.textContent = "Waking up.";
    state.sleeping = false;
    state.fatal = false;
    state.retries = 0;
    try {
      if (!playCtx || playCtx.state === "closed") createContexts();
      await playCtx.resume();
      await micCtx.resume();
      if (!micStream) await startMic();
    } catch (err) {
      const blocked = err && (err.name === "NotAllowedError" || err.name === "SecurityError");
      return showWake(blocked
        ? "Microphone access was blocked. Allow it in the address bar, then try again."
        : `Audio could not start: ${err && err.message}`, true);
    }
    el.wake.hidden = true;
    el.hud.hidden = false;
    connect(true);
  }

  function sleep() {
    state.sleeping = true;
    stopVideo();
    stopMic();
    stopPlayback();
    if (state.ws) { const ws = state.ws; state.ws = null; ws.close(); }
    setPhase("offline");
    showWake("EV is asleep. Wake it when you need it.", false);
  }

  el.wakeBtn.addEventListener("click", wake);
  el.sleepBtn.addEventListener("click", sleep);
  el.camBtn.addEventListener("click", () => toggleVideo("camera"));
  el.screenBtn.addEventListener("click", () => toggleVideo("screen"));
  el.micBtn.addEventListener("click", () => {
    state.micOn = !state.micOn;
    el.micBtn.classList.toggle("on", state.micOn);
    el.micBtn.classList.toggle("off", !state.micOn);
    el.micBtn.setAttribute("aria-pressed", String(state.micOn));
    el.micBtn.querySelector("span").textContent = state.micOn ? "Mic on" : "Mic muted";
    if (!state.micOn && state.ws && state.ws.readyState === WebSocket.OPEN) state.ws.send(JSON.stringify({ type: "audio_end" }));
  });

  // ------------------------------------------------------------ real data panels

  async function getJSON(url) {
    const reply = await fetch(url, { cache: "no-store" });
    if (!reply.ok) throw new Error(url);
    return reply.json();
  }

  function meter(key, name) {
    const wrap = document.createElement("div");
    wrap.className = "meter";
    wrap.dataset.key = key;
    wrap.innerHTML = `<div class="row"><span>${name}</span><b>0%</b></div><div class="bar"><i style="width:0"></i></div>`;
    el.meters.append(wrap);
    return wrap;
  }

  function setMeter(key, name, value) {
    let wrap = el.meters.querySelector(`[data-key="${key}"]`) || meter(key, name);
    wrap.querySelector("b").textContent = `${Math.round(value)}%`;
    wrap.querySelector("i").style.width = `${Math.min(100, value)}%`;
    wrap.classList.toggle("hot", value > 85);
  }

  async function loadStatus() {
    try {
      const s = await getJSON("/api/status");
      setMeter("cpu", "Processor", s.cpu_percent);
      setMeter("ram", "Memory", s.ram_percent);
      setMeter("disk", "Disk", s.disk_percent);
      if (s.battery_percent !== null) setMeter("bat", s.charging ? "Battery, charging" : "Battery", s.battery_percent);
      el.sysMeta.textContent = `${s.os}, ${s.cpu_cores} cores, ${s.ram_used_gb} of ${s.ram_total_gb} GB memory, up ${s.uptime_hours} h`;
    } catch (_) {
      el.sysMeta.textContent = "System stats unavailable.";
    }
  }

  async function loadWeather() {
    try {
      const w = await getJSON("/api/weather");
      if (w.error) throw new Error(w.error);
      el.weather.innerHTML = "";
      const temp = document.createElement("span");
      temp.className = "temp";
      temp.textContent = `${Math.round(w.temperature_c)}°C`;
      const desc = document.createElement("span");
      desc.className = "desc";
      desc.textContent = `${w.condition}, ${w.place}. Feels like ${Math.round(w.feels_like_c)}°, humidity ${w.humidity_percent}%, wind ${Math.round(w.wind_kmh)} km/h`;
      el.weather.append(temp, desc);
    } catch (_) {
      el.weather.innerHTML = '<span class="meta">Weather is unavailable right now.</span>';
    }
  }

  async function loadReminders() {
    try {
      const { reminders } = await getJSON("/api/reminders");
      el.reminders.innerHTML = "";
      if (!reminders.length) {
        el.reminders.innerHTML = '<li class="empty">Nothing scheduled.</li>';
        return;
      }
      const today = new Date().toDateString();
      reminders.slice(0, 6).forEach((r) => {
        const when = new Date(r.due);
        const li = document.createElement("li");
        const text = document.createElement("span");
        text.textContent = r.message;
        const time = document.createElement("span");
        time.className = "when";
        const hm = when.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
        time.textContent = when.toDateString() === today ? hm : `${when.toLocaleDateString([], { day: "numeric", month: "short" })} ${hm}`;
        li.append(text, time);
        el.reminders.append(li);
      });
    } catch (_) { /* leave the old list */ }
  }

  async function loadConfig() {
    try {
      const c = await getJSON("/api/config");
      el.spec.textContent = `${c.tool_count} tools, ${c.model}`;
      el.agents.innerHTML = "";
      Object.entries(c.agents).forEach(([key, name]) => {
        const li = document.createElement("li");
        li.dataset.key = key;
        li.innerHTML = '<span class="dot"></span><span class="name"></span><span class="state">idle</span>';
        li.querySelector(".name").textContent = name;
        el.agents.append(li);
      });
    } catch (_) { /* HUD still works without it */ }
  }

  function tick() {
    el.clock.textContent = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }

  // ------------------------------------------------------------ reactor drawing

  function fit(canvas) {
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const w = Math.max(1, Math.round(canvas.clientWidth * dpr));
    const h = Math.max(1, Math.round(canvas.clientHeight * dpr));
    if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
  }

  function reactor(canvas, t, level, phase, bars) {
    fit(canvas);
    const ctx = canvas.getContext("2d");
    const w = canvas.width, h = canvas.height;
    const cx = w / 2, cy = h / 2, R = Math.min(w, h) * 0.38;
    const [r, g, b] = COLORS[phase] || COLORS.offline;
    const rgba = (a) => `rgba(${r},${g},${b},${a})`;
    ctx.clearRect(0, 0, w, h);

    const glow = ctx.createRadialGradient(cx, cy, R * 0.1, cx, cy, R * (1.25 + level * 0.5));
    glow.addColorStop(0, rgba(0.22 + level * 0.3));
    glow.addColorStop(1, rgba(0));
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, w, h);

    // outer ring with ticks
    ctx.lineWidth = Math.max(1, R * 0.008);
    ctx.strokeStyle = rgba(0.45);
    ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.stroke();
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(t * 0.05);
    for (let i = 0; i < 72; i++) {
      const long = i % 6 === 0;
      ctx.strokeStyle = rgba(long ? 0.7 : 0.3);
      ctx.beginPath();
      ctx.moveTo(R * (long ? 1.0 : 1.0), 0); ctx.lineTo(R * (long ? 1.085 : 1.045), 0);
      ctx.stroke(); ctx.rotate((Math.PI * 2) / 72);
    }
    ctx.restore();

    // counter-rotating dashed segments
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(-t * 0.18);
    ctx.lineWidth = R * 0.022;
    for (let i = 0; i < 3; i++) {
      ctx.strokeStyle = rgba(0.65);
      ctx.beginPath(); ctx.arc(0, 0, R * 0.86, i * 2.094, i * 2.094 + 1.15); ctx.stroke();
    }
    ctx.restore();

    // audio ring from real levels
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(-Math.PI / 2);
    const count = 64;
    for (let i = 0; i < count; i++) {
      // Start at the top and mirror left and right so the ring stays balanced.
      const half = Math.min(i, count - i);
      const bin = bars ? bars[Math.floor((half / (count / 2)) * 28)] / 255 : 0;
      const wobble = (Math.sin(i * 1.7 + t * 6) + 1) / 2;
      const v = bars ? bin : level * (0.35 + 0.65 * wobble);
      const len = R * (0.03 + v * 0.2);
      ctx.strokeStyle = rgba(0.35 + v * 0.6);
      ctx.lineWidth = Math.max(1.5, R * 0.016);
      ctx.beginPath(); ctx.moveTo(R * 0.64, 0); ctx.lineTo(R * 0.64 + len, 0); ctx.stroke();
      ctx.rotate((Math.PI * 2) / count);
    }
    ctx.restore();

    // radar sweep
    if (ctx.createConicGradient) {
      const sweep = ctx.createConicGradient(t * 0.9, cx, cy);
      sweep.addColorStop(0, rgba(0.28)); sweep.addColorStop(0.12, rgba(0)); sweep.addColorStop(1, rgba(0));
      ctx.fillStyle = sweep;
      ctx.beginPath(); ctx.arc(cx, cy, R * 0.6, 0, Math.PI * 2); ctx.fill();
    }

    // reactor core
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(t * 0.35);
    ctx.lineWidth = R * 0.05;
    for (let i = 0; i < 6; i++) {
      ctx.strokeStyle = rgba(0.85);
      ctx.beginPath(); ctx.arc(0, 0, R * 0.34, i * 1.047 + 0.08, i * 1.047 + 0.9); ctx.stroke();
    }
    ctx.restore();
    const core = ctx.createRadialGradient(cx, cy, 0, cx, cy, R * (0.22 + level * 0.1));
    core.addColorStop(0, "rgba(255,255,255,0.95)");
    core.addColorStop(0.35, rgba(0.95));
    core.addColorStop(1, rgba(0));
    ctx.fillStyle = core;
    ctx.beginPath(); ctx.arc(cx, cy, R * (0.24 + level * 0.1), 0, Math.PI * 2); ctx.fill();
  }

  let smooth = 0;
  function frame(ms) {
    const t = ms / 1000;
    let target = 0, bars = null;
    if (state.phase === "speaking" && analyser) {
      analyser.getByteFrequencyData(freq);
      bars = freq;
      let sum = 0;
      for (let i = 0; i < 48; i++) sum += freq[i];
      target = Math.min(1, (sum / 48 / 255) * 1.8);
    } else if (state.micOn && state.phase === "listening") {
      target = state.micLevel;
    }
    smooth += (target - smooth) * 0.2;
    if (!el.hud.hidden) reactor(el.orb, t, smooth, state.phase, bars);
    if (!el.wake.hidden) reactor(el.wakeRing, t, 0.06 + 0.04 * Math.sin(t * 1.4), state.fatal ? "error" : "listening", null);
    requestAnimationFrame(frame);
  }

  // ------------------------------------------------------------ start up

  tick(); setInterval(tick, 1000);
  loadConfig(); loadStatus(); loadWeather(); loadReminders();
  setInterval(loadStatus, 3000);
  setInterval(loadReminders, 20000);
  setInterval(loadWeather, 600000);
  requestAnimationFrame(frame);
})();

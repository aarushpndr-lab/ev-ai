// Turns microphone audio into 16 kHz, 16-bit mono chunks that Gemini Live expects.
class MicProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.ratio = sampleRate / 16000;
    this.phase = 0;
    this.sum = 0;
    this.count = 0;
    this.out = [];
  }

  process(inputs) {
    const channel = inputs[0] && inputs[0][0];
    if (!channel) return true;

    for (let i = 0; i < channel.length; i++) {
      this.sum += channel[i];
      this.count += 1;
      this.phase += 1;
      if (this.phase >= this.ratio) {
        this.phase -= this.ratio;
        this.out.push(this.sum / this.count);
        this.sum = 0;
        this.count = 0;
      }
    }

    // About 40 ms per chunk keeps latency low without flooding the socket.
    while (this.out.length >= 640) {
      const chunk = this.out.splice(0, 640);
      const pcm = new Int16Array(640);
      for (let i = 0; i < 640; i++) {
        const v = Math.max(-1, Math.min(1, chunk[i]));
        pcm[i] = v < 0 ? v * 0x8000 : v * 0x7fff;
      }
      this.port.postMessage(pcm.buffer, [pcm.buffer]);
    }
    return true;
  }
}

registerProcessor("mic-processor", MicProcessor);
